<div class="row">
	<div class="col-lg-13">
		<div class="alert alert-danger">
         <p>Bạn chưa chọn trường dữ liệu nào cả.Gửi lại báo cáo tuần <a href="<?php echo Yii::app()->request->baseUrl.'/piadmin/Customer/';?>">tại đây</a></p>
      </div>
	</div>
</div>