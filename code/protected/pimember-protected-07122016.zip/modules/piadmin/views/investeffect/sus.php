<div class="row">
   <div class="col-lg-12">
      <div class="alert alert-success">
      <p>Gửi báo tuần đến khách hàng thành công.Tiếp tục gửi báo cáo tuần <a href="<?php echo Yii::app()->request->baseUrl.'/piadmin/Customer/';?>">tại đây</a></p>
      </div>
   </div>
</div>