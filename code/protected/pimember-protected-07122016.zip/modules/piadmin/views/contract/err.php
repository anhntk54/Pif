<?php if($err==1){ ?>
<div class="form-group alert alert-danger">
   <label for="disabledSelect">Lỗi để trống dữ liệu khách hàng</label>
</div>
<?php } ?>