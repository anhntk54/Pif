<?php
/* @var $this HomeController */

$this->breadcrumbs=array(
	'Home',
);
?>
<div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Hệ thống đang nâng cấp</h1>
                </div>
                <!-- /.col-lg-12 -->
 </div>
 <div class="row">
     <div class="col=lg-12">
	     <div class="alert alert-info panel-default">
		   <div class="panel-body">
		     <p> Kỹ thuật viên đang nâng cấp hệ thống.Xin quý khách vui lòng thông cảm </p>
			 <p> Mọi chi tiết xin liên hệ kỹ thuật viên</p>
			 <p> Email: <a href="mailto:hoangtrungmta94@gmail.com">hoangtrungmta94@gmail.com</a></p>
			 <p> Số điện thoại: <a href="tel:01679343575">0167 934 3575</a></p>
		   </div>
		 </div>
	 </div>
 </div>
            <!-- /.row -->
           
    
           
